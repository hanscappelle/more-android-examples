import os
import shutil

srcfile = 'test.txt'

for x in range (0,1750):
	shutil.copy(srcfile, 'test-'+str(x)+'.txt')
